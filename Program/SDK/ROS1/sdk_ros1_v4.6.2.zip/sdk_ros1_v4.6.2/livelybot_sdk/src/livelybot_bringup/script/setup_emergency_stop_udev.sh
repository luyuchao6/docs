#!/bin/bash

# 脚本：自动为特定 USB 设备（VID=1a86, PID=8040）创建 udev 规则
# 功能：设置权限、所有者和创建符号链接

# 获取当前用户名
CURRENT_USER=$(whoami)

# 定义 udev 规则目录和规则文件名
UDEV_RULES_DIR="/etc/udev/rules.d"
RULE_FILE="$UDEV_RULES_DIR/99-emergency-stop.rules"

# 检查是否以 root 权限运行
if [ "$EUID" -ne 0 ]; then
    echo "⚠️  此脚本需要 root 权限。请使用 sudo 运行:"
    echo "  sudo $0"
    exit 1
fi

# 创建 udev 规则内容，并替换用户名
echo "📝 正在创建 udev 规则文件: $RULE_FILE"
cat > "$RULE_FILE" << EOF
# 紧急停止设备规则 (VID=1a86, PID=8040)
# 自动生成于 $(date)
SUBSYSTEM=="tty", ATTRS{idVendor}=="1a86", ATTRS{idProduct}=="8040", OWNER="$CURRENT_USER", GROUP="dialout", MODE="0666", SYMLINK+="emergency_stop"
# 如果需要设备插入时直接触发脚本，可以取消注释并修改下一行中的路径
# SUBSYSTEM=="tty", ATTRS{idVendor}=="1a86", ATTRS{idProduct}=="8040", ACTION=="add", RUN+="/path/to/your/emergency_stop_monitor_script.sh"
EOF

# 设置规则文件权限
chmod 644 "$RULE_FILE"

# 重新加载 udev 规则
echo "🔄 重新加载 udev 规则..."
udevadm control --reload-rules
udevadm trigger

echo "✅ 完成！UDEV 规则已安装并生效。"
echo "   设备所有者: $CURRENT_USER"
echo "   符号链接: /dev/emergency_stop"
echo "   权限: 0666 (读/写对所有用户)"
