#include <ros/ros.h>
#include <livelybot_power/Power_switch.h>
#include <serial/serial.h>
#include <iostream>
#include <fstream> // 用于文件存在性检查
#include <unistd.h> // 用于 access() 函数

#define DBG_MODE    0
// 定义颜色宏
#define YELLOW "\033[33m"
#define RESET "\033[0m"

ros::Publisher power_pub;
serial::Serial ser;
std::string port_name = "/dev/emergency_stop";
const int BAUD_RATE = 115200;

// 检查文件是否存在 (使用C标准库函数access)
bool file_exists(const std::string& filename) {
    return (access(filename.c_str(), F_OK) != -1);
}

// 尝试初始化或重新连接串口
bool init_serial() {
    try {
        // 首先检查设备文件是否存在
        if (!file_exists(port_name)) {
            std::cout << "Serial device file does not exist: " << port_name << std::endl;
            return false;
        }

        if (ser.isOpen()) {
            ser.close();
            std::cout << "Serial port closed, attempting to reconnect..." << std::endl;
        }
        
        ser.setPort(port_name);
        ser.setBaudrate(BAUD_RATE);
        serial::Timeout timeout = serial::Timeout::simpleTimeout(500);
        ser.setTimeout(timeout);
        ser.open();
        
        if (ser.isOpen()) {
            std::cout << "Serial port opened successfully: " << port_name << std::endl;
            return true;
        } else {
            std::cerr << YELLOW << "Failed to open serial port: " << RESET << port_name << std::endl;
            return false;
        }
    } catch (const serial::IOException& e) {
        std::cerr << YELLOW <<  "IOException when opening serial port: " << RESET << e.what() << std::endl;
        return false;
    } catch (const std::exception& e) {
        std::cerr << YELLOW << "Unknown exception when opening serial port: " << RESET << e.what() << std::endl;
        return false;
    }
}

// 检查串口数据
void check_serial_data() {
    if (!ser.isOpen()) {
        return;
    }

    try {
        size_t bytes_available = ser.available();
        if (bytes_available > 0) {
            // 读取串口数据
            std::string data = ser.read(ser.available());
            #if DBG_MODE
            std::cout << "received: " << data << std::endl;
            #endif            
            // 检查是否包含触发信号"1"
            if (data.find('1') != std::string::npos) {
                livelybot_power::Power_switch power_switch;
                power_switch.control_switch = true;
                power_switch.power_switch = false;
                power_pub.publish(power_switch);
                std::cout << YELLOW << "\rEmergency Stop!" << RESET;
                std::cout.flush();
            }
            else if(data.find('0') != std::string::npos) {
                std::cout << YELLOW << "\rEmergency Run!" << RESET;
                std::cout.flush();
            }
        }
    } catch (const serial::IOException& e) {
        std::cerr << YELLOW << "Error reading from serial port: " << e.what() << RESET << std::endl;
        std::cerr << YELLOW << "Serial device not available. Attempting to reconnect..." << RESET <<  std::endl;
        ser.close();
    } catch (const std::exception& e) {
        std::cerr << YELLOW << "Unknown error processing serial data: " << e.what() << RESET << std::endl;
        ser.close();
    }
}

int main(int argc, char **argv) {
    ros::init(argc, argv, "serial_emergency_stop");
    ros::NodeHandle nh;
    ros::NodeHandle private_nh("~");

    power_pub = nh.advertise<livelybot_power::Power_switch>("power_switch_control", 1);

    bool serial_connected = init_serial();
    if (!serial_connected) {
        std::cerr << YELLOW << "Initial serial connection failed. The program will continue running and attempt to reconnect." << RESET << std::endl;
    }

    std::cout << "Serial emergency stop monitor started. Waiting for serial signal..." << std::endl;

    ros::Rate loop_rate(100); // 10Hz
    int reconnect_counter = 0;

    while (ros::ok()) {
        // 先检查设备文件是否存在，再尝试打开串口
        if (!ser.isOpen()) {
            // if (reconnect_counter++ % 500 == 0) { // 大约每5秒打印一次
            //     std::cout << "Serial device not available. Attempting to reconnect..." << std::endl;
            // }
            
            // 只有设备文件存在时才尝试重新连接
            if (file_exists(port_name)) {
                serial_connected = init_serial();
            }
        } else {
            check_serial_data();
        }

        ros::spinOnce();
        loop_rate.sleep();
    }

    if (ser.isOpen()) {
        ser.close();
        std::cout << "Serial port closed on program exit." << std::endl;
    }

    return 0;
}
