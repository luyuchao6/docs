#include <ros/ros.h>
#include <string>
#include <sstream>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <livelybot_logger/LoggerStatus.h>
#include <livelybot_logger/LoggerOperation.h>
#include "livelybot_logger/logger_interface.h"
#include <iomanip>
#include <sensor_msgs/JointState.h>
#include <sensor_msgs/Imu.h>
#include <tf/transform_datatypes.h>
#include <livelybot_power/Power_switch.h>
#include <std_msgs/Float32.h>
#include <cstdio>    // for popen
#include <memory>    // for std::unique_ptr
#include <stdexcept> // for std::runtime_error
#include <array>     // for std::array
#include <algorithm> // for std::remove
#include <vector>    // for std::vector
#include <map>       // for std::map
#include <regex>     // for std::regex
#include <thread>    // for std::thread
#include <chrono>    // for std::chrono
#include <future>    // for std::async
#include <ctime>     // for time
#include <std_msgs/Int8.h>
#include <std_msgs/UInt8.h>
#include <cstdint>
#include <ros/master.h> 
#include <atomic>
#include <iostream>

using namespace livelybot_logger; // 添加命名空间
uint8_t motor_number = 0;
uint64_t motor_last_update_time_ms = 0;

#define SOCKET_PATH "/tmp/logger_service.sock"
#define MOTOR_COUNT 40

struct MotorStatus
{
    double position;
    double velocity;
    double torque;
    bool motor_position_disconnected;
    MotorStatus() : position(0), velocity(0), torque(0), motor_position_disconnected(true) {}
};

struct ImuStatus
{
    struct
    {
        double x, y, z;
    } acceleration;
    struct
    {
        double x, y, z;
    } angular_velocity;
    struct
    {
        double roll, pitch, yaw;
    } euler_angles;
    uint64_t last_update_time_ms;
    ImuStatus() : last_update_time_ms(0) {}
};

struct PowerStatus
{
    enum class SwitchState
    {
        UNKNOWN = -1,
        OFF = 0,
        ON = 1
    };
    SwitchState system_power;
    SwitchState motor_power;
    uint64_t last_update_time_ms;
    PowerStatus() : system_power(SwitchState::UNKNOWN), motor_power(SwitchState::UNKNOWN), last_update_time_ms(0) {}
};

struct BatteryStatus
{
    double voltage;
    double current;
    double temperature;
    uint8_t level;
    uint64_t voltage_last_update_time_ms;
    uint64_t current_last_update_time_ms;
    uint64_t temperature_last_update_time_ms;
    uint64_t level_last_update_time_ms;
    BatteryStatus() : voltage(0), current(0), temperature(0), level(0), voltage_last_update_time_ms(0), current_last_update_time_ms(0), temperature_last_update_time_ms(0), level_last_update_time_ms(0) {} // 添加构造函数
};

// 添加ROS节点资源数据结构
struct NodeStatus
{
    std::string name;
    std::string status;
    std::string cpu;
    std::string memory;
    NodeStatus(const std::string &n, const std::string &s, const std::string &c, const std::string &m) : name(n), status(s), cpu(c), memory(m) {}
};

uint64_t getSystemTimeMs()
{
    return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();
}

// 带超时的系统命令执行函数
std::string execSystemCommandWithTimeout(const char *cmd, int timeout_ms = 500)
{
    // 添加超时参数到命令
    std::string timeout_cmd = std::string("timeout ") + std::to_string(timeout_ms / 1000.0) + " " + cmd + " 2>/dev/null";

    std::array<char, 128> buffer;
    std::string result;
    std::unique_ptr<FILE, decltype(&pclose)> pipe(popen(timeout_cmd.c_str(), "r"), pclose);
    if (!pipe)
    {
        ROS_WARN("Command execution failed: %s", cmd);
        return "";
    }

    while (fgets(buffer.data(), buffer.size(), pipe.get()) != nullptr)
    {
        result += buffer.data();
    }
    return result;
}

void logMessageFrequency(const std::string &name, int trigger_count)
{
    // 用静态变量保存上次时间点和计数
    static std::map<std::string, std::pair<uint64_t, int>> stat_map;
    auto &stat = stat_map[name];
    auto &last_time_ms = stat.first;
    auto &count = stat.second;

    if (last_time_ms == 0)
    {
        last_time_ms = getSystemTimeMs();
        count = 0;
    }
    count++;
    if (count >= trigger_count)
    {
        uint64_t now_ms = getSystemTimeMs();
        uint64_t elapsed_ms = now_ms - last_time_ms;

        double freq = 0;
        if (elapsed_ms > 0)
        {
            freq = (count * 1000.0) / elapsed_ms;
        }
        std::ostringstream data_stream;
        data_stream << "[FreqLog] " << name << ": " << std::fixed << std::setprecision(2) << freq << " Hz (" << count << " msgs in " << elapsed_ms << " ms)";
        LoggerInterface::logOperation("INFO", data_stream.str());
        last_time_ms = now_ms;
        count = 0;
    }
}

bool checkConnectionLost(uint64_t last_recv_time_ms, double expected_freq, int max_missing_frames)
{
    uint64_t now_ms = getSystemTimeMs();
    uint64_t elapsed_ms = now_ms - last_recv_time_ms;

    // 计算允许的最大时间间隔（ms），超过即认为丢帧断联
    double max_elapsed_ms = (1000.0 / expected_freq) * max_missing_frames;

    return elapsed_ms >= max_elapsed_ms;
}

class LoggerNode
{
private:
    ros::NodeHandle nh_;
    ros::Timer status_timer_;
    ros::Timer heartbeat_timer_;
    ros::Timer power_switch_timer_;
    ros::Timer battery_volt_timer_;
    ros::Timer battery_curr_timer_;
    ros::Timer battery_temp_timer_;
    ros::Timer battery_level_timer_;
    ros::Timer joint_state_timer_;
    ros::Timer imu_timer_;
    ros::Timer ros_node_timer_;
    ros::Subscriber joint_state_sub_;
    ros::Subscriber imu_sub_;
    ros::Subscriber operation_sub_;
    ros::Subscriber power_switch_sub_;  // 添加功率板开关状态订阅者
    ros::Subscriber battery_volt_sub_;  // 添加电池电压订阅器
    ros::Subscriber battery_curr_sub_;  // 添加电池电流订阅器
    ros::Subscriber battery_temp_sub_;  // 添加电池温度订阅器
    ros::Subscriber battery_level_sub_; // 添加电池电量订阅器
    ros::Subscriber bms_error_sub_;     // 添加电池错误信息话题订阅者
    int socket_fd_;
    bool socket_initialized_; // 添加socket初始化状态标志

    // 状态数据
    MotorStatus motors_[MOTOR_COUNT];
    ImuStatus imu_;
    PowerStatus power_;
    BatteryStatus battery_;

    // 系统资源使用数据
    float system_cpu_usage_;
    float system_memory_usage_;
    float system_disk_usage_;
    float cpu_temperature_; // 添加CPU温度变量
    bool resource_info_valid_;

    // ROS节点状态数据
    std::vector<NodeStatus> node_statuses_;

    // 参数
    double heartbeat_interval_;
    double status_send_interval_;
    double system_info_interval_;
    double power_timeout_check_interval_;
    double battery_volt_check_interval_;
    double battery_curr_check_interval_;
    double battery_temp_check_interval_;
    double battery_level_check_interval_;
    double joint_check_interval_;
    double imu_check_interval_;
    double ros_node_check_interval_;

    bool power_disconnected = true;
    bool battery_volt_disconnected = true;
    bool battery_curr_disconnected = true;
    bool battery_temp_disconnected = true;
    bool battery_level_disconnected = true;
    bool joint_state_disconnected = true;
    bool imu_disconnected = true;

    void initializeSocket()
    {
        socket_fd_ = socket(AF_UNIX, SOCK_DGRAM, 0);
        if (socket_fd_ == -1)
        {
            ROS_ERROR("Failed to create socket");
            socket_initialized_ = false;
            return;
        }
        socket_initialized_ = true;
    }

    bool sendMessage(const std::string &message)
    {
        if (!socket_initialized_ || message.empty())
        {
            ROS_ERROR("Cannot send message: socket not initialized or empty message");
            return false;
        }

        // 添加消息大小检查
        if (message.length() > 4000)
        {
            ROS_WARN("Message length (%zu bytes) is close to BUFFER_SIZE limit!", message.length());
        }

        struct sockaddr_un addr;
        memset(&addr, 0, sizeof(addr));
        addr.sun_family = AF_UNIX;
        strncpy(addr.sun_path, SOCKET_PATH, sizeof(addr.sun_path) - 1);

        ssize_t sent = sendto(socket_fd_, message.c_str(), message.length(), 0,
                              (struct sockaddr *)&addr, sizeof(addr));

        if (sent == -1)
        {
            ROS_ERROR("Failed to send message: %s, error: %s",
                      message.c_str(), strerror(errno));
            return false;
        }
        else if (sent != static_cast<ssize_t>(message.length()))
        {
            ROS_WARN("Partial send: %zd of %zu bytes", sent, message.length());
            return false;
        }

        return true;
    }

    void jointStateCallback(const sensor_msgs::JointState::ConstPtr &msg)
    {
        // logMessageFrequency("JointState", 100);
        motor_number = msg->position.size();
        motor_last_update_time_ms = getSystemTimeMs();
        std::ostringstream disconnected_stream;
        std::ostringstream reconnected_stream;
        std::ostringstream motor_all;
        bool has_disconnected = false;
        bool has_reconnected = false;
        disconnected_stream << "MOTOR_POSITION_INVALID: ";
        reconnected_stream << "MOTOR_POSITION_RECONNECTED: ";
        motor_all << "motor_all:";
        for (size_t i = 0; i < motor_number; i++)
        {
            motors_[i].position = msg->position[i];
            motors_[i].velocity = msg->velocity[i];
            motors_[i].torque = msg->effort[i];
            if (motors_[i].position == -999)
            {
                if (!motors_[i].motor_position_disconnected)
                {
                    if (has_disconnected)
                        disconnected_stream << ", ";
                    disconnected_stream << "M" << (i + 1);
                    motors_[i].motor_position_disconnected = true;
                    has_disconnected = true;
                }
            }
            else
            {
                if (motors_[i].motor_position_disconnected)
                {
                    if (has_reconnected)
                        reconnected_stream << ", ";
                    reconnected_stream << "M" << (i + 1);
                    motors_[i].motor_position_disconnected = false;
                    has_reconnected = true;
                }
            }
            motor_all << "M" << (i + 1) << ":" << motors_[i].position << ",";
        }
        if (has_disconnected)
        {
            livelybot_logger::LoggerInterface::logOperation("ERROR", disconnected_stream.str());
        }
        if (has_reconnected)
        {
            livelybot_logger::LoggerInterface::logOperation("INFO", reconnected_stream.str());
        }
        // livelybot_logger::LoggerInterface::logOperation("INFO", motor_all.str());
    }

    void imuCallback(const sensor_msgs::Imu::ConstPtr &msg)
    {
        // logMessageFrequency("IMU", 100);
        imu_.last_update_time_ms = getSystemTimeMs();
        // 更新加速度数据
        imu_.acceleration.x = msg->linear_acceleration.x;
        imu_.acceleration.y = msg->linear_acceleration.y;
        imu_.acceleration.z = msg->linear_acceleration.z;

        // 更新角速度数据
        imu_.angular_velocity.x = msg->angular_velocity.x;
        imu_.angular_velocity.y = msg->angular_velocity.y;
        imu_.angular_velocity.z = msg->angular_velocity.z;

        // 从四元数转换为欧拉角
        tf::Quaternion q(msg->orientation.x, msg->orientation.y, msg->orientation.z, msg->orientation.w);
        tf::Matrix3x3 rot_mat(q);
        rot_mat.getRPY(imu_.euler_angles.roll, imu_.euler_angles.pitch, imu_.euler_angles.yaw);
    }

    void powerSwitchCallback(const livelybot_power::Power_switch::ConstPtr &msg)
    {
        // logMessageFrequency("power", 50);
        // 更新接收时间
        power_.last_update_time_ms = getSystemTimeMs();
        // 判断 system_power 是否变化
        PowerStatus::SwitchState new_system_power = (msg->control_switch == 1) ? PowerStatus::SwitchState::ON : PowerStatus::SwitchState::OFF;
        if (power_.system_power != new_system_power)
        {
            std::ostringstream stream;
            stream << "System power changed: " << (new_system_power == PowerStatus::SwitchState::ON ? "ON" : "OFF");
            livelybot_logger::LoggerInterface::logOperation("INFO", stream.str());
            power_.system_power = new_system_power;
        }
        // 判断 motor_power 是否变化
        PowerStatus::SwitchState new_motor_power = (msg->power_switch == 1) ? PowerStatus::SwitchState::ON : PowerStatus::SwitchState::OFF;
        if (power_.motor_power != new_motor_power)
        {
            std::ostringstream stream;
            stream << "Motor power changed: " << (new_motor_power == PowerStatus::SwitchState::ON ? "ON" : "OFF");
            livelybot_logger::LoggerInterface::logOperation("INFO", stream.str());
            power_.motor_power = new_motor_power;
        }
    }

    void batteryVoltCallback(const std_msgs::Float32::ConstPtr &msg)
    {
        // logMessageFrequency("bv", 50);
        battery_.voltage = msg->data;
        battery_.voltage_last_update_time_ms = getSystemTimeMs();
    }

    void batteryCurrCallback(const std_msgs::Float32::ConstPtr &msg)
    {
        // logMessageFrequency("bc", 50);
        battery_.current = msg->data;
        battery_.current_last_update_time_ms = getSystemTimeMs();
    }

    void batteryTempCallback(const std_msgs::Float32::ConstPtr &msg)
    {
        // logMessageFrequency("bt", 50);
        battery_.temperature = msg->data;
        battery_.temperature_last_update_time_ms = getSystemTimeMs();
    }

    void batteryLevelCallback(const std_msgs::UInt8::ConstPtr &msg)
    {
        // logMessageFrequency("bl", 50);
        battery_.level = msg->data;
        battery_.level_last_update_time_ms = getSystemTimeMs();
        static uint8_t last_logged_level = 255;
        if (battery_.level < 10)
        {
            if (battery_.level < last_logged_level)
            {
                last_logged_level = battery_.level;
                std::ostringstream stream;
                stream << "Low battery warning: " << static_cast<int>(battery_.level) << "% remaining";
                livelybot_logger::LoggerInterface::logOperation("WARN", stream.str());
            }
        }
        else
        {
            last_logged_level = 255;
        }
    }

    void bmsErrorCallback(const std_msgs::Int8::ConstPtr &msg)
    {
        std::ostringstream data_stream;
        data_stream << "BMS_ERROR_CODE: " << static_cast<int>(msg->data);
        livelybot_logger::LoggerInterface::logOperation("ERROR", data_stream.str());
    }

    // 实现系统状态检查函数
    void checkSystemStatus()
    {
        // 检查CPU温度
        if (resource_info_valid_ && cpu_temperature_ > 80.0)
        { // 假设80°C是高温阈值
            // 使用LoggerInterface发送CPU高温警报
            std::ostringstream data_stream;
            data_stream << "HIGH_CPU_TEMP:" << cpu_temperature_ << "°C";
            LoggerInterface::logOperation("ERROR", data_stream.str());
        }
        // 系统资源监测
        if (resource_info_valid_)
        {
            // 检查CPU使用率
            if (system_cpu_usage_ > 90.0)
            {
                std::ostringstream data_stream;
                data_stream << "HIGH_CPU_USAGE:" << system_cpu_usage_ << "%";
                LoggerInterface::logOperation("ERROR", data_stream.str());
            }

            // 检查内存使用率
            if (system_memory_usage_ > 90.0)
            {
                std::ostringstream data_stream;
                data_stream << "HIGH_MEMORY_USAGE:" << system_memory_usage_ << "%";
                LoggerInterface::logOperation("ERROR", data_stream.str());
            }

            // 检查磁盘使用率
            if (system_disk_usage_ > 90.0)
            {
                std::ostringstream data_stream;
                data_stream << "HIGH_DISK_USAGE:" << system_disk_usage_ << "%";
                LoggerInterface::logOperation("ERROR", data_stream.str());
            }
        }
    }

    void powerSwitchCheckCallback(const ros::TimerEvent &)
    {
        bool lost = checkConnectionLost(power_.last_update_time_ms, 8.0, 5);
        if (lost && !power_disconnected)
        {
            power_disconnected = true;
            LoggerInterface::logOperation("ERROR", "[FreqLog] power: Connection lost");
        }
        else if (!lost && power_disconnected && power_.last_update_time_ms > 0)
        {
            power_disconnected = false;
            LoggerInterface::logOperation("INFO", "[FreqLog] power: Connection restored");
        }
    }

    void batteryVoltCheckCallback(const ros::TimerEvent &)
    {
        bool lost = checkConnectionLost(battery_.voltage_last_update_time_ms, 8.0, 5);
        if (lost && !battery_volt_disconnected)
        {
            battery_volt_disconnected = true;
            LoggerInterface::logOperation("ERROR", "[FreqLog] battery_volt: Connection lost");
        }
        else if (!lost && battery_volt_disconnected && battery_.voltage_last_update_time_ms > 0)
        {
            battery_volt_disconnected = false;
            LoggerInterface::logOperation("INFO", "[FreqLog] battery_volt: Connection restored");
        }
    }

    void batteryCurrCheckCallback(const ros::TimerEvent &)
    {
        bool lost = checkConnectionLost(battery_.current_last_update_time_ms, 8.0, 5);
        if (lost && !battery_curr_disconnected)
        {
            battery_curr_disconnected = true;
            LoggerInterface::logOperation("ERROR", "[FreqLog] battery_curr: Connection lost");
        }
        else if (!lost && battery_curr_disconnected && battery_.current_last_update_time_ms > 0)
        {
            battery_curr_disconnected = false;
            LoggerInterface::logOperation("INFO", "[FreqLog] battery_curr: Connection restored");
        }
    }

    void batteryTempCheckCallback(const ros::TimerEvent &)
    {
        bool lost = checkConnectionLost(battery_.temperature_last_update_time_ms, 8.0, 5);
        if (lost && !battery_temp_disconnected)
        {
            battery_temp_disconnected = true;
            LoggerInterface::logOperation("ERROR", "[FreqLog] battery_temp: Connection lost");
        }
        else if (!lost && battery_temp_disconnected && battery_.temperature_last_update_time_ms > 0)
        {
            battery_temp_disconnected = false;
            LoggerInterface::logOperation("INFO", "[FreqLog] battery_temp: Connection restored");
        }
    }

    void batteryLevelCheckCallback(const ros::TimerEvent &)
    {
        bool lost = checkConnectionLost(battery_.level_last_update_time_ms, 8.0, 5);
        if (lost && !battery_level_disconnected)
        {
            battery_level_disconnected = true;
            LoggerInterface::logOperation("ERROR", "[FreqLog] battery_level: Connection lost");
        }
        else if (!lost && battery_level_disconnected && battery_.level_last_update_time_ms > 0)
        {
            battery_level_disconnected = false;
            LoggerInterface::logOperation("INFO", "[FreqLog] battery_level: Connection restored");
        }
    }

    void jointStateCheckCallback(const ros::TimerEvent &)
    {
        bool lost = checkConnectionLost(motor_last_update_time_ms, 10.0, 5);
        if (lost && !joint_state_disconnected)
        {
            joint_state_disconnected = true;
            LoggerInterface::logOperation("ERROR", "[FreqLog] joint_state: Connection lost");
        }
        else if (!lost && joint_state_disconnected && motor_last_update_time_ms > 0)
        {
            joint_state_disconnected = false;
            LoggerInterface::logOperation("INFO", "[FreqLog] joint_state: Connection restored");
        }
    }

    void imuCheckCallback(const ros::TimerEvent &)
    {
        bool lost = checkConnectionLost(imu_.last_update_time_ms, 10.0, 5);
        if (lost && !imu_disconnected)
        {
            imu_disconnected = true;
            LoggerInterface::logOperation("ERROR", "[FreqLog] imu: Connection lost");
        }
        else if (!lost && imu_disconnected && imu_.last_update_time_ms > 0)
        {
            imu_disconnected = false;
            LoggerInterface::logOperation("INFO", "[FreqLog] imu: Connection restored");
        }
    }

    void statusCallback(const ros::TimerEvent &)
    { 
        // 构建状态消息
        std::ostringstream status_msg;
        status_msg << "STATUS:";

        // 添加电机数据
        status_msg << "MOTOR;";
        for (int i = 0; i < motor_number; i++)
        {
            status_msg << "M" << (i + 1) << ",";
            if (motor_last_update_time_ms)
            {
                status_msg << "pos:" << std::fixed << std::setprecision(6) << motors_[i].position << ","
                            << "vel:" << std::fixed << std::setprecision(6) << motors_[i].velocity << ","
                            << "tor:" << std::fixed << std::setprecision(6) << motors_[i].torque;
            }
            else
            {
                status_msg << "pos:NULL,vel:NULL,tor:NULL";
            }
            if (i < motor_number - 1)
                status_msg << ";";
        }

        // 添加IMU数据
        status_msg << ";IMU,";
        if (imu_.last_update_time_ms)
        {
            status_msg << "acc:" << imu_.acceleration.x << "/"
                        << imu_.acceleration.y << "/"
                        << imu_.acceleration.z << ","
                        << "gyro:" << imu_.angular_velocity.x << "/"
                        << imu_.angular_velocity.y << "/"
                        << imu_.angular_velocity.z << ","
                        << "euler:" << imu_.euler_angles.roll << "/"
                        << imu_.euler_angles.pitch << "/"
                        << imu_.euler_angles.yaw;
        }
        else
        {
            status_msg << "acc:NULL/NULL/NULL,"
                        << "gyro:NULL/NULL/NULL,"
                        << "euler:NULL/NULL/NULL";
        }

        // 添加电源状态
        status_msg << ";POWER,";
        if (power_.last_update_time_ms)
        {
            status_msg << "sys:" << (power_.system_power == PowerStatus::SwitchState::ON ? "1" : power_.system_power == PowerStatus::SwitchState::OFF ? "0"
                                                                                                                                                        : "NULL")
                        << ","
                        << "motor:" << (power_.motor_power == PowerStatus::SwitchState::ON ? "1" : power_.motor_power == PowerStatus::SwitchState::OFF ? "0"
                                                                                                                                                        : "NULL");
        }
        else
        {
            status_msg << "sys:NULL,motor:NULL";
        }

        // 添加电池状态
        status_msg << ";BATTERY,"
                    << "volt:" << (battery_.voltage_last_update_time_ms ? std::to_string(battery_.voltage) : "NULL") << ","
                    << "curr:" << (battery_.current_last_update_time_ms ? std::to_string(battery_.current) : "NULL") << ","
                    << "temp:" << (battery_.temperature_last_update_time_ms ? std::to_string(battery_.temperature) : "NULL") << ","
                    << "remain:" << (battery_.level_last_update_time_ms ? std::to_string(battery_.level) : "NULL");

        // 添加系统资源使用信息
        status_msg << ";SYSTEM_RESOURCES,";
        if (resource_info_valid_)
        {
            status_msg << "cpu:" << std::fixed << std::setprecision(2) << system_cpu_usage_ << "%,"
                        << "mem:" << std::fixed << std::setprecision(2) << system_memory_usage_ << "%,"
                        << "disk:" << std::fixed << std::setprecision(2) << system_disk_usage_ << "%,"
                        << "cpu_temp:" << std::fixed << std::setprecision(2) << cpu_temperature_ << "°C";
        }
        else
        {
            status_msg << "cpu:NULL,mem:NULL,disk:NULL,cpu_temp:NULL";
        }

        // 直接添加ROS节点状态信息到同一个消息中，而不是分开发送
        for (size_t i = 0; i < node_statuses_.size(); i++)
        {
            const auto &node = node_statuses_[i];
            status_msg << ";ROS_NODE,"
                        << "node:" << node.name << ","
                        << "status:" << node.status;
        }

        // 发送合并后的状态消息
        bool sent = sendMessage(status_msg.str());
    }

    void heartbeatCallback(const ros::TimerEvent &)
    {
        sendMessage("HEARTBEAT");
    }

    void operationCallback(const livelybot_logger::LoggerOperation::ConstPtr &msg)
    {
        std::string message = "OPERATION:" + msg->operation_type + " | " + msg->operation_data;
        sendMessage(message);
    }

    // 获取系统资源占用信息
    void systemInfoCallback()
    {
        try
        {
            // 获取CPU负载
            std::string cpu_cmd = "top -bn1 | grep 'Cpu(s)' | awk '{print $2 + $4}'";
            std::string cpu_output = execSystemCommandWithTimeout(cpu_cmd.c_str(), 1000);
            if (!cpu_output.empty())
            {
                system_cpu_usage_ = std::stof(cpu_output);
            }

            // 获取内存使用率
            std::string mem_cmd = "free | grep Mem | awk '{print $3/$2 * 100.0}'";
            std::string mem_output = execSystemCommandWithTimeout(mem_cmd.c_str(), 1000);
            if (!mem_output.empty())
            {
                system_memory_usage_ = std::stof(mem_output);
            }

            // 获取磁盘使用率
            std::string disk_cmd = "df -h / | grep / | awk '{print $5}' | sed 's/%//'";
            std::string disk_output = execSystemCommandWithTimeout(disk_cmd.c_str(), 1000);
            if (!disk_output.empty())
            {
                system_disk_usage_ = std::stof(disk_output);
            }

            // 获取CPU温度
            try
            {
                // 方法1: 通过/sys/class/thermal获取温度
                std::string thermal_cmd = "cat /sys/class/thermal/thermal_zone*/temp 2>/dev/null | sort -nr | head -n1";
                std::string thermal_output = execSystemCommandWithTimeout(thermal_cmd.c_str(), 1000);
                if (!thermal_output.empty())
                {
                    // 转换为摄氏度（文件中通常是毫摄氏度）
                    cpu_temperature_ = std::stof(thermal_output) / 1000.0f;
                }
                else
                {
                    // 方法2: 通过sensors命令
                    std::string sensors_cmd = "sensors 2>/dev/null | grep -i 'core\\|temp' | grep ':' | awk '{print $2}' | sed 's/[^0-9.]//g' | sort -nr | head -n1";
                    std::string sensors_output = execSystemCommandWithTimeout(sensors_cmd.c_str(), 1000);
                    if (!sensors_output.empty())
                    {
                        cpu_temperature_ = std::stof(sensors_output);
                    }
                    else
                    {
                        // 如果两种方法都失败，标记为无效数据
                        cpu_temperature_ = 0.0f;
                    }
                }
            }
            catch (const std::exception &e)
            {
                cpu_temperature_ = 0.0f;
                ROS_DEBUG("获取CPU温度失败: %s", e.what()); // 防止未使用的变量警告
            }

            resource_info_valid_ = true;
        }
        catch (const std::exception &e)
        {
            resource_info_valid_ = false;
            ROS_ERROR("Failed to get system resource info: %s", e.what());
        }
    }

    void updateNodeStatusInfo(const ros::TimerEvent &)
    {
        std::vector<std::string> target_nodes = {
            "/joy_node", "/joy_teleop", "/livelybot_oled_node",
            "/power_node", "/rosout", "/livelybot_logger",
            "/sim2real_master_node", "/yesense_imu_node"};

        std::vector<std::string> all_nodes;
        if (!ros::master::getNodes(all_nodes))
        {
            ROS_WARN("Failed to get node list from ROS master.");
            return;
        }

        node_statuses_.clear();

        for (const auto& node_name : target_nodes)
        {
            std::string status = "stopped";
            if (std::find(all_nodes.begin(), all_nodes.end(), node_name) != all_nodes.end())
            {
                status = "run";
            }

            node_statuses_.emplace_back(node_name, status, "NULL", "NULL");
        }
    }

public:

    std::thread system_check_thread;
    std::atomic<bool> running{true};

    LoggerNode() : nh_("~"), system_cpu_usage_(0.0f), system_memory_usage_(0.0f),
                   system_disk_usage_(0.0f), cpu_temperature_(0.0f), resource_info_valid_(false)
    {
        // 初始化节点状态信息，使用默认值而不是实时获取，避免在构造函数中卡住
        for (const auto &node_name : {"/joy_node", "/joy_teleop", "/livelybot_oled_node", "/power_node", "/rosout", "/livelybot_logger", "/sim2real_master_node", "/yesense_imu_node"})
        {
            node_statuses_.emplace_back(node_name, "unknown", "0%", "0%");
        }

        // 获取参数
        nh_.param("heartbeat_interval", heartbeat_interval_, 1.0);                      // 心跳发送间隔
        nh_.param("status_send_interval", status_send_interval_, 5.0);                  // 状态发送间隔
        nh_.param("power_timeout_check_interval", power_timeout_check_interval_, 0.1); // 电源状态检测间隔
        nh_.param("battery_volt_check_interval", battery_volt_check_interval_, 0.1);   // 电压检测间隔
        nh_.param("battery_curr_check_interval", battery_curr_check_interval_, 0.1);   // 电流检测间隔
        nh_.param("battery_temp_check_interval", battery_temp_check_interval_, 0.1);   // 温度检测间隔
        nh_.param("battery_level_check_interval", battery_level_check_interval_, 0.1); // 电量检测间隔
        nh_.param("joint_check_interval", joint_check_interval_, 0.1);                 // 关节状态检测间隔
        nh_.param("imu_check_interval", imu_check_interval_, 0.1);                     // IMU 检测间隔
        nh_.param("ros_node_check_interval", ros_node_check_interval_, 0.5);           // ros节点检测间隔

        // 初始化socket
        initializeSocket();

        // 发送启动日志
        sendMessage("OPERATION:livelybot_logger_node_start");
        // 订阅电机数据
        joint_state_sub_ = nh_.subscribe("/error_joint_states", 30, &LoggerNode::jointStateCallback, this);
        // 订阅IMU数据
        imu_sub_ = nh_.subscribe("/imu/data", 30, &LoggerNode::imuCallback, this);
        // 订阅功率板开关状态
        power_switch_sub_ = nh_.subscribe("/power_switch_state", 1, &LoggerNode::powerSwitchCallback, this);
        // 订阅bms_error
        bms_error_sub_ = nh_.subscribe("/bms_error", 1, &LoggerNode::bmsErrorCallback, this);
        // 添加电池电压订阅
        battery_volt_sub_ = nh_.subscribe("/battery_voltage", 1, &LoggerNode::batteryVoltCallback, this);
        // 添加电池电流订阅
        battery_curr_sub_ = nh_.subscribe("/battery_current", 1, &LoggerNode::batteryCurrCallback, this);
        // 添加电池温度订阅
        battery_temp_sub_ = nh_.subscribe("/battery_temperature", 1, &LoggerNode::batteryTempCallback, this);
        // 添加电池电量订阅
        battery_level_sub_ = nh_.subscribe("/battery_level", 1, &LoggerNode::batteryLevelCallback, this);
        operation_sub_ = nh_.subscribe("/logger/operation", 30, &LoggerNode::operationCallback, this);

        // 先发送一次状态数据
        statusCallback(ros::TimerEvent());

        // 创建状态数据定时器
        status_timer_ = nh_.createTimer(ros::Duration(status_send_interval_), &LoggerNode::statusCallback, this);
        // 创建心跳定时器
        heartbeat_timer_ = nh_.createTimer(ros::Duration(heartbeat_interval_), &LoggerNode::heartbeatCallback, this);
        // 创建电源开关状态定时器
        power_switch_timer_ = nh_.createTimer(ros::Duration(power_timeout_check_interval_), &LoggerNode::powerSwitchCheckCallback, this);
        // 电池电压定时器
        battery_volt_timer_ = nh_.createTimer(ros::Duration(battery_volt_check_interval_), &LoggerNode::batteryVoltCheckCallback, this);
        // 电池电流定时器
        battery_curr_timer_ = nh_.createTimer(ros::Duration(battery_curr_check_interval_), &LoggerNode::batteryCurrCheckCallback, this);
        // 电池温度定时器
        battery_temp_timer_ = nh_.createTimer(ros::Duration(battery_temp_check_interval_), &LoggerNode::batteryTempCheckCallback, this);
        // 电池电量定时器
        battery_level_timer_ = nh_.createTimer(ros::Duration(battery_level_check_interval_), &LoggerNode::batteryLevelCheckCallback, this);
        // 关节状态定时器
        joint_state_timer_ = nh_.createTimer(ros::Duration(joint_check_interval_), &LoggerNode::jointStateCheckCallback, this);
        // IMU 状态定时器
        imu_timer_ = nh_.createTimer(ros::Duration(imu_check_interval_), &LoggerNode::imuCheckCallback, this);
        //ros节点状态定时器
        ros_node_timer_ = nh_.createTimer(ros::Duration(ros_node_check_interval_), &LoggerNode::updateNodeStatusInfo, this);

        system_check_thread = std::thread([this]() {
            while (running)
            {
                systemInfoCallback();
                std::this_thread::sleep_for(std::chrono::seconds(1));
            }
        });
    }

    ~LoggerNode()
    {
        running = false;
        if (system_check_thread.joinable())
            system_check_thread.join();
        if (socket_fd_ >= 0)
        {
            close(socket_fd_);
        }
    }
};

int main(int argc, char **argv)
{
    ros::init(argc, argv, "livelybot_logger");
    ros::NodeHandle nh;
    ros::NodeHandle private_nh("~");

    // 先初始化LoggerInterface
    livelybot_logger::LoggerInterface::init(nh, "livelybot_logger");

    // 创建LoggerNode实例
    LoggerNode logger_node;
    ros::spin();

    return 0;
}
