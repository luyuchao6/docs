#include <iostream>
#include <ros/ros.h>
#include "livelybot_power.hpp"
#include <std_msgs/Float32.h>
#include <std_msgs/UInt8.h> // 添加 Int8 消息头文件
#include <std_msgs/Int8.h> // 添加 Int8 消息头文件
#include <std_msgs/String.h>
#include <livelybot_power/Power_switch.h>
#include "livelybot_power/VersionInfo.h"
#include <ctime>
#include <cstdint>

#define TIME_CAN_ID 0x04

// 全局变量
ros::Publisher battery_volt_pub;
ros::Publisher battery_curr_pub; // 添加电池电流发布者
ros::Publisher battery_temp_pub; // 添加电池温度发布者
ros::Publisher battery_level_pub; 
ros::Publisher power_switch_pub; // 添加功率板开关状态发布者
ros::Publisher bms_error_pub;    // 添加 BMS 错误话题发布者
ros::Publisher version_pub;      // 添加 版本号 话题发布者
ros::Subscriber power_switch_sub;     
livelybot_can::CAN_Driver can_handler("can0");

typedef enum __attribute__((packed))
{
  VERSION_Ctrl = 0,    //控制算法
  VERSION_SDK = 1,     //SDK
  VERSION_Oled = 2,    //OLED
  VERSION_Power = 3,   //功率板
  VERSION_Com = 4,     //通信版
  VERSION_BMS = 5,     //电池
  VERSION_Mot_L = 6,   //电机最低版本
  VERSION_Mot_U = 7,   //电机最高版本
} version_type_s;


// 自定义CAN接收回调函数
void custom_can_recv_parse(int can_id, unsigned char *data, unsigned char len)
{
// BMS地址定义
#define BMS_ADDR 0x06
// 功率板地址定义
#define POWER_SWITCH_ADDR 0x07

    uint8_t dev_addr;
    uint8_t data_type;
    uint8_t append_flag;

    dev_addr = can_id >> 7;
    data_type = (can_id >> 1) & 0x3F;
    append_flag = can_id & 0x01;

    if (!append_flag && dev_addr == BMS_ADDR && data_type == 0x01)
    {
        // 发布电池电压
        std_msgs::Float32 volt_msg;
        volt_msg.data = (*(int16_t *)&data[0]) / 100.0f;
        battery_volt_pub.publish(volt_msg);

        // 发布电池电流
        std_msgs::Float32 curr_msg;
        curr_msg.data = (*(int16_t *)&data[2]) / 100.0f;
        battery_curr_pub.publish(curr_msg);

        // 发布电池温度
        std_msgs::Float32 temp_msg;
        temp_msg.data = (*(int16_t *)&data[4]) / 100.0f;
        battery_temp_pub.publish(temp_msg);

        std_msgs::UInt8 level_msg;
        level_msg.data = data[6]; 
        battery_level_pub.publish(level_msg);
    }
    else if (!append_flag && dev_addr == BMS_ADDR && data_type == 0x02)
    {
        // 发布 BMS 错误信息
        std_msgs::Int8 error_msg;
        error_msg.data = data[0];
        bms_error_pub.publish(error_msg);
    }
    else if (!append_flag && dev_addr == POWER_SWITCH_ADDR && data_type == 0x02)
    {
        // 处理功率板开关状态
        livelybot_power::Power_switch power_switch_msg;
        power_switch_msg.control_switch = data[0];
        power_switch_msg.power_switch = data[1];
        power_switch_pub.publish(power_switch_msg);
        // ROS_INFO("Power Switch: %d, %d", power_switch_msg.control_switch, power_switch_msg.power_switch);
    }
    else if(!append_flag && dev_addr == POWER_SWITCH_ADDR && data_type == 0x05)
    {
        livelybot_power::VersionInfo msg;
        msg.device_type = VERSION_Power;
        msg.version = std::string(reinterpret_cast<char*>(data), len); // 仅存版本号字符串
        version_pub.publish(msg);
    }
    else if(!append_flag && dev_addr == BMS_ADDR && data_type == 0x05)
    {
        livelybot_power::VersionInfo msg;
        msg.device_type = VERSION_BMS;
        msg.version = std::string(reinterpret_cast<char*>(data), len);
        version_pub.publish(msg);
    }
}

void power_switch_callback(const livelybot_power::Power_switch& msg)
{
    #define ORANGEPI_ADDR       0x01
    uint32_t can_id = (ORANGEPI_ADDR<<7) | (1 << 1) | 0;
    uint8_t data[2];
    
    data[0] = msg.control_switch;
    data[1] = msg.power_switch;

    can_handler.send(can_id, data, 2);
}


int main(int argc, char **argv)
{
    ros::init(argc, argv, "power_node");
    ros::NodeHandle n;

    // 初始化发布者
    battery_volt_pub = n.advertise<std_msgs::Float32>("battery_voltage", 1);
    battery_curr_pub = n.advertise<std_msgs::Float32>("battery_current", 1);
    battery_temp_pub = n.advertise<std_msgs::Float32>("battery_temperature", 1);            // 添加温度话题
    battery_level_pub = n.advertise<std_msgs::UInt8>("battery_level", 1);            // 
    power_switch_pub = n.advertise<livelybot_power::Power_switch>("power_switch_state", 1); // 添加功率板开关状态发布
    bms_error_pub = n.advertise<std_msgs::Int8>("bms_error", 1); // 初始化 BMS 错误话题发布者
    version_pub = n.advertise<livelybot_power::VersionInfo>("version", 10); // 发布版本信息
    power_switch_sub = n.subscribe("power_switch_control", 1, power_switch_callback);

    can_handler.start_callback(custom_can_recv_parse);

    uint32_t can_id = (TIME_CAN_ID<<7) | (1 << 1) | 0;
    std::time_t last_sent_ts = 0;  // 上一次发送的秒数

    // 主循环
    ros::Rate r(10);
    while (ros::ok())
    {
        ros::spinOnce();
        // 获取当前的 UTC 时间戳（秒）
        std::time_t now = std::time(nullptr);

        // 每秒只更新一次时间戳并发送
        if (now != last_sent_ts)  
        {
            last_sent_ts = now;

            // 发北京时间
            uint32_t unix_ts = static_cast<uint32_t>(now); 

            uint8_t data[4];
            data[0] = (unix_ts >> 0) & 0xFF;
            data[1] = (unix_ts >> 8) & 0xFF;
            data[2] = (unix_ts >> 16) & 0xFF;
            data[3] = (unix_ts >> 24) & 0xFF;

            can_handler.send(can_id, data, 4);
            // std::cout << "Send timestamp: " << unix_ts << std::endl;
        }
        r.sleep();
    }

    return 0;
}
