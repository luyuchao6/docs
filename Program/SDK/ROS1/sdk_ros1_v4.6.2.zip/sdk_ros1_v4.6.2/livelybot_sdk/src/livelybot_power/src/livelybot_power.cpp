#include "livelybot_power.hpp"

livelybot_can::CAN_Driver can_handler(CAN_DEVICE_NAME);
ros::Publisher battery_volt_pub;
ros::Publisher battery_curr_pub;
ros::Publisher battery_temp_pub;
ros::Publisher battery_level_pub;
ros::Publisher power_detect_pub;
ros::Publisher power_switch_pub;
ros::Subscriber power_switch_sub;

void can_recv_parse(int id, unsigned char *data, unsigned char len);
void power_switch_callback(const livelybot_power::Power_switch &msg);

using namespace livelybot_can;

Power_Board::Power_Board()
{
}

void Power_Board::run(ros::NodeHandle &n)
{
    ros::Rate r(10);
    battery_volt_pub = n.advertise<std_msgs::Float32>("battery_voltage", 1);
    battery_curr_pub = n.advertise<std_msgs::Float32>("battery_current", 1);
    battery_temp_pub = n.advertise<std_msgs::Float32>("battery_temp", 1);
    battery_level_pub = n.advertise<std_msgs::UInt8>("battery_level", 1);
    power_switch_pub = n.advertise<livelybot_power::Power_switch>("power_switch_state", 1);
    power_detect_pub = n.advertise<livelybot_power::Power_detect>("power_detect_state", 1);
    power_switch_sub = n.subscribe("power_switch_control", 1, power_switch_callback);
    can_handler.start_callback(can_recv_parse);
    while (ros::ok())
    {
        r.sleep();
        ros::spinOnce();
    }
}

#define ORANGEPI_ADDR 0x01
#define BMS_ADDR 0x06
#define POWER_SWITCH_ADDR 0x07

void can_recv_parse(int can_id, unsigned char *data, unsigned char dlc)
{
    
}

void power_switch_callback(const livelybot_power::Power_switch &msg)
{
    uint32_t can_id = (ORANGEPI_ADDR << 7) | (1 << 1) | 0;
    uint8_t data[2];

    data[0] = msg.control_switch;
    data[1] = msg.power_switch;

    can_handler.send(can_id, data, 2);
}
